INSERT INTO DepartmentT VALUES(1,'Police');
INSERT INTO DepartmentT VALUES(2,'CBI');
INSERT INTO DepartmentT VALUES(3,'FireService');
INSERT INTO DepartmentT VALUES(4,'ElectionCommision');
INSERT INTO DepartmentT VALUES(5,'Google Search');
