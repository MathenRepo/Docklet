package com.eureka.registryhome;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurekaregistryMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
