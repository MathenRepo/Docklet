package com.hystrix.fallback;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FallBackServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
